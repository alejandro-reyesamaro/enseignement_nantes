#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>

//LE BERRE TOM 402C


typedef struct {
	int N;							// seasons (12: months)
    int * reproduction_seasons;		// reproduction months (bit-flags)
    int * hunting_seasons;			// hunting seasons (bit-flags)
} t_park_seasons;

// Park rules declaration
t_park_seasons seasons;

/// \function: read_seasons
/// \abstract: read the rules of the park from a text file called "fseasons"
/// \input: -
/// \output: t_park_seasons representing reproduction and hunting seasons
t_park_seasons read_seasons()
{
	t_park_seasons seasons;
	seasons.N = 12;
	seasons.reproduction_seasons 	= malloc(sizeof(int) * 12);
	seasons.hunting_seasons 		= malloc(sizeof(int) * 12);

	FILE * file = fopen("np_rules.txt", "r");
	int i;
	char c;
	for(i = 0; i < 12; i++)
	{
		c = (char)fgetc(file);
		seasons.reproduction_seasons[i] = atoi(&c);
	}
	c = (char)fgetc(file);
	for(i = 0; i < 12; i++)
	{
		c = (char)fgetc(file);
		seasons.hunting_seasons[i] = atoi(&c);
	}
	return seasons;
}

/// \function: print_seasons
/// \abstract: print in console the content of a t_park_season object
/// \input: t_park_seasons representing reproduction and hunting seasons
/// \output: -
void print_seasons(t_park_seasons seasons)
{
	int i;
	for(i = 0; i < seasons.N; i++)
		printf("%d ", seasons.reproduction_seasons[i]);
	printf("\n"); // reading "\n"
	for(i = 0; i < seasons.N; i++)
		printf("%d ", seasons.hunting_seasons[i]);
	printf("\n");
}

/*******************************************************************/

void Rule_park (t_park_seasons seasons)		//Fonction
{

	char OH[] =	"Only hunting";
	char N[] = 	"Nothing";
	char OR[] =	"Only reproduction";
	char RH[] =	"Reprodution and hunting";


		for(int i = 0; i < seasons.N ; i++)
		{
			if(seasons.reproduction_seasons[i]== 1 && seasons.hunting_seasons == 1)
				printf("%i -> %s",i +1, RH);
			if(seasons.reproduction_seasons[i]==0 && seasons.hunting_seasons == 1)
				printf("%i -> %s",i+1,OH);
			if(seasons.reproduction_seasons[i]==1 && seasons.hunting_seasons == 0)
				printf("%i -> %s", i+1, OR);
			if(seasons.reproduction_seasons[i]==0 && seasons.hunting_seasons == 0)
				printf("%i -> %s", i+1, N);
		
	}
}

/*******************************************************************/

void Test(t_park_seasons seasons)
{
	char N[] = 	"Nothing";
	char RH[] =	"Reprodution and hunting";
	char OR[] =	"Only reproduction";
	char OH[] =	"Only hunting";

	pid_t pid;
	pid = fork();

	if(pid == 0)
		ProcessusA(seasons);
	else
		ProcessusB(seasons);
}

/*******************************************************************/

void ProcessusA(t_park_seasons seasons) //Pour reproduction (pas de hunting) processus fils
{
	char OR[] =	"Only reproduction";

	for(int i=0; i<seasonsN ; i++)
		if(seasons.reproduction_seasons[i]== 1)
			printf("%i -> %s",i +1, OR);
}

/*******************************************************************/

void ProcessusB(t_park_seasons seasons) // Pour hunting (pas de reproduction) processus père
{
	char OH[] =	"Only hunting";

	for(int i=0; i<seasonsN ; i++)
		if(seasons.hunting_seasons[i]== 1)
			printf("%i -> %s",i +1, OH );
}

/*******************************************************************/

int main(int argc, char *argv[])
{
	seasons = read_seasons();
	print_seasons(seasons);
	Rule_park(seasons);
	return 0;
}



// TO COMPILE
// gcc proc_2017.c -lpthread -std=c99 -o proc && ./proc