Vous devez pour la premi�re version vous placer dans text output, et saisir le mot � faire deviner avant de
proposer des lettres.

Vous devez pour la seconde version vous placer dans text output ou graphic output, et saisir le mot a faire
deviner avant de proposer des lettres.

Vous devez pour la troisi�me version vous placer dans text output ou graphic output, puis directement proposer
les lettres.