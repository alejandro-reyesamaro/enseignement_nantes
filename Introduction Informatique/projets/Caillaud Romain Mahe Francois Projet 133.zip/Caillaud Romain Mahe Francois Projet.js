/*Introduction a l'informatique. Projet n5, chaines de caract�res
Caillaud Romain et Mahe Francois, groupe 133
--------------------------------------------------------------------*/

function noaccent(lettre) { //On cr�e une fonction qui retire les accents d'une lettre
  if ((lettre == '�') || (lettre == '�') || (lettre == '�')) {
    lettre = 'e';
  }
  if ((lettre == '�') || (lettre == '�')) {
    lettre = 'a';
  }
  if ((lettre == '�') || (lettre == '�')) {
    lettre = 'u';
  }
  if (lettre == '�') {
    lettre = 'c';
  }
  if (lettre == '�') {
    lettre = 'i';
  }
  if (lettre == '�') {
    lettre = 'o';
  }
  return lettre
}


function cryptage(message, cle) {

  var output = "";

  //on v�rifie si les caract�res sont en majuscule ou en minuscule
  var carmess = new Array(); //tableau qui va contenir les caract�res du message
  var carcle = new Array(); //tableau qui va contenir les caract�res de la cl�	
  var decal = new Array(); //tableau qui va contenir le d�calage
  for (var h = 0; h <= Taille(message) - 1; h = h + 1) {
    carmess[h] = message.charAt(h);
    carcle[h] = cle.charAt(h);

    if ((carmess[h] == Majuscule(carmess[h])) && (carcle[h] == Majuscule(carcle[h]))) {
      decal[h] = 65; //d�calage correspondant au A majuscule en ASCII
    } else {
      decal[h] = 97; //d�calage correspondant au a minuscule en ASCII
    }
    if ((carmess[h] == Majuscule(carmess[h])) && (carcle[h] != Majuscule(carcle[h]))) {
      decal[h] = 45; // decalage permettant de retrouver la lettre en majuscule 
    }

  }

  //on cr�e un tableau correspondant aux caract�res du message
  var tabcarac = new Array();
  for (var i = 0; i <= Taille(message) - 1; i = i + 1) {
    tabcarac[i] = message.charAt(i); //.charAt(i) permet de prendre le caract�re du mot en i
    tabcarac[i] = noaccent(tabcarac[i]);
    tabcarac[i] = Caractere_vers_Ascii(tabcarac[i]) - decal[i];
  }

  //on cr�e un tableau correspondant � la cle
  var tabcle = new Array();
  for (var j = 0; j <= Taille(cle) - 1; j = j + 1) {
    tabcle[j] = cle.charAt(j);
    tabcle[j] = Caractere_vers_Ascii(tabcle[j]) - decal[j];
  }

  //on cr�e un tableau correspondant au message crypt�
  var tabmesscrypt = new Array();
  for (k = 0; k <= Taille(message) - 1; k = k + 1) {
    tabmesscrypt[k] = (tabcarac[k] + tabcle[k % Taille(cle)]) % 26;
    output = output + Ascii_vers_Caractere(tabmesscrypt[k] + decal[k]);
  }
  return 'le message crypt� est : ' + output;
}

Saisie(cryptage(Saisie('Saisir message a crypter'), Saisie('Saisir cle')));

function decryptage(message, cle) {
  var carmesscrypt = new Array();
  var carcle = new Array();
  var tabmesscrypt = new Array();
  var output = "";
  var decal = new Array();

  //on v�rifie si les caract�res sont en majuscule ou en minuscule
  for (var h = 0; h <= Taille(message) - 1; h = h + 1) {
    carmesscrypt[h] = message.charAt(h);
    carcle[h] = cle.charAt(h);

    if ((carmesscrypt[h] == Majuscule(carmesscrypt[h])) && (carcle[h] == Majuscule(carcle[h]))) {
      decal[h] = 65; //d�calage correspondant au A majuscule en ASCII
    } else {
      decal[h] = 97; //d�calage correspondant au a minuscule en ASCII
    }
    if ((carmesscrypt[h] == Majuscule(carmesscrypt[h])) && (carcle[h] != Majuscule(carcle[h]))) {
      decal[h] = 45; // decalage permettant de retrouver la lettre en majuscule 
    }
  }

  //on cr�e un tableau correspondant aux caract�res du message crypt�
  for (var i = 0; i <= Taille(message) - 1; i = i + 1) {
    tabmesscrypt[i] = message.charAt(i);
    tabmesscrypt[i] = noaccent(tabmesscrypt[i]);
    tabmesscrypt[i] = Caractere_vers_Ascii(tabmesscrypt[i]) - decal[i];
  }

  //on cr�e un tableau correspondant � la cle
  var tabcle = new Array();
  for (var j = 0; j <= Taille(cle) - 1; j = j + 1) {
    tabcle[j] = cle.charAt(j);
    tabcle[j] = Caractere_vers_Ascii(tabcle[j]) - decal[j];
  }

  //on cr�e un tableau correspondant au message
  var tabcarac = new Array();
  for (var k = 0; k <= Taille(message) - 1; k = k + 1) {
    tabcarac[k] = Math.abs(tabmesscrypt[k] - tabcle[k % Taille(cle)] % 26);

    output = output + Ascii_vers_Caractere(tabcarac[k] + decal[k]);
  }
  return 'le message d�crypt� est : ' + output;
}

Ecrire(decryptage(Saisie('Saisir message crypt�'), Saisie('saisir cle')));
//Pour une cle de longueur 5 on a 26^5 cl�s possibles, donc 26^5 decodages possibles, 
//c'est � dire 11881376 d�codages possibles. Ce n'est donc pas r�aliste d�afficher 
//tous les d�codages possibles et de demander � un humain de trouver celui qui est le bon.

function friedman(messcrypt, intervalle) {

  var tablettre = new Array();
  var nblettre = new Array();
  var probalettre = new Array();
  var ic = 0;
  var longueurcle;
  var taillemess = Taille(messcrypt);
  var h = 0;
  var carmesscrypt = new Array();
  var messcryptraite = "";
  var h = 0

  while (h <= taillemess - 1) {
    carmesscrypt[h] = messcrypt.charAt(h);
    carmesscrypt[h] = noaccent(carmesscrypt[h]); //on retire les accents du mot crypt�
    if (carmesscrypt[h] == Majuscule(carmesscrypt[h])) {
      var decal = 65;
    } else {
      decal = 97;
    }
    messcryptraite += carmesscrypt[h];
    h++
  }



  //on cherche � calculer l'indice de coincidence du message crypt�
  for (var j = 0; j <= 25; j = j + intervalle) { // on va balayer tout l'alphabet donc 26 fois
    tablettre[j] = Ascii_vers_Caractere(j + decal); //tableau contenant les lettres de l'alphabet
    for (nblettre[j] = -1, index = -2; index != -1; nblettre[j]++, index = messcryptraite.indexOf(tablettre[j], index + 1)); //tableau permettant de compter le nombre de caractere dans une chaine
    probalettre[j] = (nblettre[j] * (nblettre[j] - 1)) / (taillemess * (taillemess - 1)); //tableau permettant de calculer la probabilit� d'avoir deux fois la meme lettre
    ic = (ic + probalettre[j]);
  }

  longueurcle = Math.abs(((0.075 - 0.038) * taillemess) / ((taillemess - 1) * ic - (0.038 * taillemess) + 0.075)); //formule permettant d'approximer la longueur de la cle selon le test de Kasiski  
  return "L'indice de coincidence est IC=" + ic + ". La longueur de la cle est d'environ " + longueurcle + "."
}


Ecrire(friedman(Saisie('Saisir message a decrypter'), (SaisieEntier(['saisir intervalle']))));
//tests
//Ecrire(friedman('wymxpvutxg',1));
//r�sultat: IC=0.0222;Longueur cl�=3.53
//Ecrire(friedman('opwulkgnvaaxg', 2));
//r�sultat obtenu: IC=0.025;Longueur cl�=4.321
//Ecrire(friedman('ezhgoixtkgyitp',3));
//r�sultat obtenu: IC=0.011;longueur cl�=1.65
//les r�sultats obtenus sont coh�rents.