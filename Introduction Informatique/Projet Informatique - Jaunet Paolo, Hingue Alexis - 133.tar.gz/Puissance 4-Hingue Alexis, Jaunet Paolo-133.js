//PUISSANCE 4
var TAILLE_CASE = 80; // constante d�finissant la taille d'une case

var jeu = ["", "", "", "", "", "", ""]; // tableau de cha�ne de caract�re contenant la grille
var situation = 'menu'; //Decrit l'etat du programme : menu/J1vsJ2/J1vsPC/fin
var stockSituation; //Stock la valeur de situation en cas de rejouer
var curseur; // entier, position du curseur du menu
curseur = 100;

AffMenu();

//**************************

function AffMenu() //Affiche le menu de depart
{
  Initialiser();

  //Fond
  RectanglePlein(0, 0, 5000, 1000, GradientLineaire(rgb(60, 150, 255), rgb(150, 230, 255), 0, 0, 1200, 1200));
  ShadowOn();
  RectanglePlein(25, 10, 400, 400, rgb(255, 211, 32));
  ShadowOff();

  //Texte puissance 4
  setCanvasFont('Stencil', '25pt', 'bold');
  Texte(160, 40, 'Puissance 4', rgb(255, 51, 51));

  //Cases
  RectanglePlein(150, 75, 200, 50, rgb(0, 132, 209));
  RectanglePlein(150, 175, 200, 50, rgb(0, 132, 209));
  RectanglePlein(150, 275, 200, 50, rgb(0, 132, 209));

  //Texte dans les cases
  setCanvasFont('time', '25pt', 'bold');
  Texte(160, 110, 'J1 vs J2', rgb(255, 255, 0));
  Texte(160, 210, 'J1 vs PC', rgb(255, 255, 0));
  Texte(160, 310, 'regles du jeu', rgb(255, 255, 0));

  //Surlignage de la case
  RectanglePlein(100, curseur, 10, 10, 'red');
  RectanglePlein(150, curseur - 25, 200, 50, rgba(255, 255, 255, 0.5));

}

//**************

function Keypressed(k) {


  if (situation == 'menu') {

    if (k == Caractere_vers_Ascii('&')) { //fleche du haut
      if (200 <= curseur && curseur <= 400) {
        curseur = curseur - 100;
      } else {
        curseur = 300;
      };
    } else if (k == Caractere_vers_Ascii('(')) { //fleche du bas
      if (100 <= curseur && curseur <= 200) {
        curseur = curseur + 100;
      } else {
        curseur = 100;

      }
    }

    AffMenu();

    // Utiliser la touche entr�e pour valider;  
    if (k == Caractere_vers_Ascii(Ascii_vers_Caractere(13))) {
      curseur = (curseur - 100) / 100;

      if (curseur == 0) {
        Initialiser();
        situation = 'J1vsJ2';
        afficherGrille();
      } else if (curseur == 1) {

        Initialiser();
        situation = 'J1vsPC';
        afficherGrille();
      } else if (curseur == 2) {

        Initialiser();
        regles();

      }
      curseur = 100;
    }
  }
}


//**********************

function afficherGrille(jeu) //Affiche la grille + interface statique(bouton rejouer/menu...)
{
  var i, j;
  var couleur;

  Initialiser();

  //Fond d�grad�
  RectanglePlein(0, 0, 5000, 1000, GradientLineaire(rgb(60, 150, 255), rgb(150, 230, 255), 0, 0, 1200, 1200));
  //Fond grille bleu
  RectanglePlein(100, 100, 7 * TAILLE_CASE, 6 * TAILLE_CASE, 'blue');

  //Affichage des cases de la grille
  for (i = 0; i < 7; i++) {
    for (j = 0; j < 6; j++) {
      Cercle2(100 + i * TAILLE_CASE + TAILLE_CASE / 2, 100 + j * TAILLE_CASE + TAILLE_CASE / 2, 0.85 * TAILLE_CASE + 10, 10, rgb(0, 0, 200), 'white');
    }
  }

  //Contours
  RectanglePlein(100 - 10, 100, 10, 6 * TAILLE_CASE, rgb(0, 0, 200)); //Gauche
  RectanglePlein(100 + 7 * TAILLE_CASE, 100, 10, 6 * TAILLE_CASE, rgb(0, 0, 200)); //Droite
  RectanglePlein(100 - 10, 100 + 6 * TAILLE_CASE, 7 * TAILLE_CASE + 2 * 10, 10, rgb(0, 0, 200)); //Bas  
  //interface informations sur le jeu
  RectanglePlein(100 + 7 * TAILLE_CASE + 100 - 10, 100 - 10, 300 + 2 * 10, 6 * TAILLE_CASE + 2 * 10, 'blue'); //Bordures
  RectanglePlein(100 + 7 * TAILLE_CASE + 100, 100, 300, 6 * TAILLE_CASE, rgb(60, 140, 255)); //Fond
  RectanglePlein(100 + 7 * TAILLE_CASE + 100, 100 + 6 * TAILLE_CASE / 3 - 4, 300, 2 * 4, 'blue'); //Ligne
  RectanglePlein(100 + 7 * TAILLE_CASE + 100, 100 + 2 * 6 * TAILLE_CASE / 3 - 4, 300, 2 * 4, 'blue'); //Ligne  
  //Mode de jeu
  setCanvasFont('time', '25pt', 'bold');
  if (situation == 'J1vsJ2') Texte(100 + 7 * TAILLE_CASE + 100, 80, 'J1vsJ2', 'black');
  else if (situation == 'J1vsPC') Texte(100 + 7 * TAILLE_CASE + 100, 80, 'J1vsPC', 'black');

  //Tour des joueurs (le rouge commence la partie)
  setCanvasFont('time', '18pt', 'bold');
  Texte(100 + 7 * TAILLE_CASE + 100 + 2 * 10, 100 + 6 * TAILLE_CASE / 3 + 10 + 18, 'Tour : ', 'black'); //Texte 'Tour :'
  Cercle2(100 + 7 * TAILLE_CASE + 100 + 100, 100 + 1.5 * 6 * TAILLE_CASE / 3, TAILLE_CASE, 10, 'black', rgb(60, 140, 255)); // Cadres
  Cercle2(100 + 7 * TAILLE_CASE + 100 + 200, 100 + 1.5 * 6 * TAILLE_CASE / 3, TAILLE_CASE, 10, 'black', rgb(60, 140, 255));
  CerclePlein(100 + 7 * TAILLE_CASE + 100 + 100, 100 + 1.5 * 6 * TAILLE_CASE / 3, TAILLE_CASE / 1.2, 'red'); //Cercle qui commence
  //Boutons "rejouer" et "menu"
  Rectangle(100 + 7 * TAILLE_CASE + 100 + 25, 100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2, 100, 0.6 * 6 * TAILLE_CASE / 3, 'black');
  Rectangle(100 + 7 * TAILLE_CASE + 100 + 175, 100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2, 100, 0.6 * 6 * TAILLE_CASE / 3, 'black');

  //Nombre de coups
  setCanvasFont('time', '14pt', 'bold');
  Texte(100 + 7 * TAILLE_CASE + 100, 120, 'Nombre de coups : 0', 'black');

}

//*********************

function MouseClick(x, y) //Se declenche lors d'un clic de la souris
{

  if (situation == 'J1vsJ2') {
    J1vsJ2(x, y);
  } else if (situation == 'J1vsPC') {
    J1vsPC(x, 4, y);
  } else if (situation == 'fin') {
    InitialiserTableau(jeu, '');

    if (x >= (100 + 7 * TAILLE_CASE + 100 + 25) && x <= (100 + 7 * TAILLE_CASE + 100 + 125) && y >= (100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2) && y <= (100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2 + 0.6 * 6 * TAILLE_CASE / 3)) { // si on clique sur le bouton menu
      situation = 'menu';
      AffMenu();
    } else if (x >= (100 + 7 * TAILLE_CASE + 100 + 175) && x <= (100 + 7 * TAILLE_CASE + 100 + 275) && y >= (100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2) && y <= (100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2 + 0.6 * 6 * TAILLE_CASE / 3)) { // si on clique sur le bouton rejou�
      situation = stockSituation;
      afficherGrille(jeu);
    }
  }

}

//**********************

function J1vsJ2(x, y) { // x,y:entiers; gere le mode de jeu J1vsJ2
  var choixColonne; // entier contenant l'indice de la colonne
  var etatFinal = ''; //chaine stockant l'etat du jeu : gagnant/nul/partie en cours
  choixColonne = SaisieColonne(jeu, x, y);
  if (choixColonne != -1) {
    JouerCoup(jeu, choixColonne);
    AfficherJeu(jeu, choixColonne);
  }

  etatFinal = Termine(jeu, false);
  if (etatFinal != '') //Si le jeu est fini
  {
    stockSituation = situation;
    situation = 'fin';

    AffFinDePartie(etatFinal);
  }

}

//***************************

function J1vsPC(x, profondeur, y) { // x,y:entiers; gere le mode de jeu J1vsPC
  var choixColonne; // entier contenant l'indice de la colonne
  var etatFinal = ''; //chaine stockant l'etat du jeu : gagnant/nul/partie en cours
  choixColonne = SaisieColonne(jeu, x, y);

  if (choixColonne != -1) {
    //TourJ1
    JouerCoup(jeu, choixColonne);
    AfficherJeu(jeu, choixColonne);

    etatFinal = Termine(jeu, false); //Test si termin�
    if (etatFinal != '') {
      stockSituation = situation;
      situation = 'fin';

      AffFinDePartie(etatFinal);
    }

    //TourPC
    if (situation == 'J1vsPC') //On test si le J1 ne vient pas de gagner
    {
      choixColonne = CalcIA(jeu, profondeur);
      JouerCoup(jeu, choixColonne);
      AfficherJeu(jeu, choixColonne);

      etatFinal = Termine(jeu, false); //Test si termin�
      if (etatFinal != '') {
        stockSituation = situation;
        situation = 'fin';

        AffFinDePartie(etatFinal);
      }
    }
  }
}

//*****************

function regles() { // fonction affichant les r�gles du jeu;
  RectanglePlein(0, 0, 5000, 1000, GradientLineaire(rgb(60, 150, 255), rgb(150, 230, 255), 0, 0, 1200, 1200));
  Texte(20, 50, 'Les r�gles du jeu du puissance 4:', 'black');
  setCanvasFont('time', '15pt', '');
  Texte(20, 150, ' Le but de ce jeu est d aligner 4 pions de meme couleur � la suite:', 'black');
  Texte(40, 200, ' .horizontalement, verticalement.', 'black');
  Texte(40, 250, ' . ... et en diagonales.', 'black');
  Texte(20, 300, ' Les joueurs jouent chacun leur tours.', 'black');
}

//******************

function SaisieColonne(jeu, x, y) //renvoie l'indice de la colonne cliqu� (-1 si pas de colonne ou colonne remplie)
{
  
  var colonne; // entier qui contient l'indice de la colonne cliqu� , -1 si erreur
  var estRempli; // un bool�en qui v�rifie si la colonne est rempli
  

  colonne = -1;
  estRempli = false;

  if (x >= 100 && x <= 100 + 7 * TAILLE_CASE && y > 100 && y < 100 + TAILLE_CASE * 6) { // si les coordon�es du clic sont sur la grille...
    colonne = Math.floor((x - 100) / TAILLE_CASE); //...alors on attribue une valeur � la variable colonne en fonction de x
    if (Longueur(jeu[colonne]) == 6) estRempli = true;
  }

  if (estRempli) colonne = -1;

  return colonne;

}

//*********************

function AfficherJeu(jeu, choixColonne) //Affiche les jetons sur la grille + affichage dynamique en cours de partie(nb de coups, tour...)
{
  
  var tailleColonne;  // nombre de pions dans la colonne choisie
  var coups; // nombre de coups jou�

  tailleColonne = Longueur(jeu[choixColonne]);
  coups = 0;

  if (CaractereEn(jeu[choixColonne], tailleColonne - 1) == 'O') {
    AnimPion(0, choixColonne, tailleColonne, 'red');
  } else if (CaractereEn(jeu[choixColonne], tailleColonne - 1) == 'X') {
    AnimPion(0, choixColonne, tailleColonne, 'yellow');
  }

  //Afficher le nombre de coups depuis le debut de la partie
  RectanglePlein(100 + 7 * TAILLE_CASE + 100, 100, 300, 6 * TAILLE_CASE / 3 - 4, rgb(60, 140, 255)); //Initialiser le compteur de coup
  coups = nbCoups(jeu);
  setCanvasFont('time', '14pt', 'bold');
  Texte(100 + 7 * TAILLE_CASE + 100, 120, 'Nombre de coups : ' + coups, rgb(0, 0, 0));


  //Affiche le tour du joueur
  CerclePlein(100 + 7 * TAILLE_CASE + 100 + 100, 100 + 1.5 * 6 * TAILLE_CASE / 3, TAILLE_CASE / 1.2, rgb(60, 140, 255)); //Initialisation
  CerclePlein(100 + 7 * TAILLE_CASE + 100 + 200, 100 + 1.5 * 6 * TAILLE_CASE / 3, TAILLE_CASE / 1.2, rgb(60, 140, 255));

  setCanvasFont('time', '18pt', 'bold');
  Texte(100 + 7 * TAILLE_CASE + 100 + 2 * 10, 100 + 6 * TAILLE_CASE / 3 + 10 + 18, 'Tour : ', 'black'); //Texte 'Tour'
  
  if (QuiLeTour()) 
    CerclePlein(100 + 7 * TAILLE_CASE + 100 + 100, 100 + 1.5 * 6 * TAILLE_CASE / 3, TAILLE_CASE / 1.2, 'red');
  else
  CerclePlein(100 + 7 * TAILLE_CASE + 100 + 200, 100 + 1.5 * 6 * TAILLE_CASE / 3, TAILLE_CASE / 1.2, 'yellow');

}

//****************************

function Termine(jeu, simulation) //verifie si le jeu est termine (victoire ou plus de jetons) et tra�e la combinaison gagnante si le plateau de jeu n'est pas simul� : renvoit une chaine de caracteres
{
  var i, j; // compteur
  var cpt; //compte le nombre de jeton jou�
  var tailleColonne; // nombre de pions dans la colonne
  var etatFinal; //chaine de caractere definisant l'etat du jeu : victoire/defaite/nul/en cours
  cpt = 0;
  fini = false;
  etatFinal = '';


  //Verification du nul
  for (i = 0; i < 7; i++) {
    tailleColonne = Longueur(jeu[i]);
    for (j = 0; j < tailleColonne; j++) {
      cpt++;
    }
  }

  if (cpt == 42) etatFinal = 'nul';


  //Verification des combinaisons horizontales
  for (i = 0; i < 4; i++) {
    tailleColonne = Longueur(jeu[i]);
    for (j = 0; j < tailleColonne; j++) {

      if (CaractereEn(jeu[i], j) == CaractereEn(jeu[i + 1], j) && CaractereEn(jeu[i + 1], j) == CaractereEn(jeu[i + 2], j) && CaractereEn(jeu[i + 2], j) == CaractereEn(jeu[i + 3], j)) {
        if (!simulation) Ligne(100 + i * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - j) * TAILLE_CASE + TAILLE_CASE / 2, 100 + (i + 3) * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - j) * TAILLE_CASE + TAILLE_CASE / 2, 'black');

        etatFinal = CaractereEn(jeu[i], j);
      }

    }
  }

  //Verification des combinaisons verticales
  for (i = 0; i < 7; i++) {
    tailleColonne = Longueur(jeu[i]);
    for (j = 0; j < tailleColonne; j++) {

      if (CaractereEn(jeu[i], j) == CaractereEn(jeu[i], j + 1) && CaractereEn(jeu[i], j + 1) == CaractereEn(jeu[i], j + 2) && CaractereEn(jeu[i], j + 2) == CaractereEn(jeu[i], j + 3)) {
        if (!simulation) Ligne(100 + i * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - j) * TAILLE_CASE + TAILLE_CASE / 2, 100 + i * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - (j + 3)) * TAILLE_CASE + TAILLE_CASE / 2, 'black');
        etatFinal = CaractereEn(jeu[i], j)
      }

    }
  }

  //Verification des combinaisons diagonales droites
  for (i = 0; i < 4; i++) {
    tailleColonne = Longueur(jeu[i]);
    for (j = 0; j < tailleColonne; j++) {

      if (CaractereEn(jeu[i], j) == CaractereEn(jeu[i + 1], j + 1) && CaractereEn(jeu[i + 1], j + 1) == CaractereEn(jeu[i + 2], j + 2) && CaractereEn(jeu[i + 2], j + 2) == CaractereEn(jeu[i + 3], j + 3)) {
        if (!simulation) Ligne(100 + i * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - j) * TAILLE_CASE + TAILLE_CASE / 2, 100 + (i + 3) * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - (j + 3)) * TAILLE_CASE + TAILLE_CASE / 2, 'black');
        etatFinal = CaractereEn(jeu[i], j)
      }

    }
  }

  //Verification des combinaisons diagonales gauches
  for (i = 3; i < 7; i++) {
    tailleColonne = Longueur(jeu[i]);
    for (j = 0; j < tailleColonne; j++) {

      if (CaractereEn(jeu[i], j) == CaractereEn(jeu[i - 1], j + 1) && CaractereEn(jeu[i - 1], j + 1) == CaractereEn(jeu[i - 2], j + 2) && CaractereEn(jeu[i - 2], j + 2) == CaractereEn(jeu[i - 3], j + 3)) {
        if (!simulation) Ligne(100 + i * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - j) * TAILLE_CASE + TAILLE_CASE / 2, 100 + (i - 3) * TAILLE_CASE + TAILLE_CASE / 2, 100 + (5 - (j + 3)) * TAILLE_CASE + TAILLE_CASE / 2, 'black');
        etatFinal = CaractereEn(jeu[i], j)
      }

    }
  }

  return etatFinal;
}

//***********************************

function AffFinDePartie(etatFinal) //Affiche les informations concernant la fin de partie : gagnant, bonton rejouer/menu...
{
  //Test sur l'etat final
  setCanvasFont('impact', '24pt', 'bold');
  if (etatFinal == 'nul') {
    Texte(150, 90, 'Match nul !', 'black');
  } else if (etatFinal == 'X') {
    Texte(150, 90, 'Victoire Jaune !', 'yellow');
  } else if (etatFinal == 'O') {
    Texte(150, 90, 'Victoire Rouge !', 'red');
  }

  //Cases des boutons "menu" et "rejouer"
  RectanglePlein(100 + 7 * TAILLE_CASE + 100 + 25, 100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2, 100, 0.6 * 6 * TAILLE_CASE / 3, rgb(10, 100, 255));
  RectanglePlein(100 + 7 * TAILLE_CASE + 100 + 175, 100 + 6 * TAILLE_CASE / 3 * (2.5 - 0.6 / 2) + 4 / 2, 100, 0.6 * 6 * TAILLE_CASE / 3, rgb(10, 100, 255));

  //Texte des cases "menu" et "rejouer"
  setCanvasFont('times', '18pt', 'bold');
  Texte(100 + 7 * TAILLE_CASE + 100 + 30, 100 + 6 * TAILLE_CASE / 3 * 2.5, 'Menu', 'black');
  Texte(100 + 7 * TAILLE_CASE + 100 + 180, 100 + 6 * TAILLE_CASE / 3 * 2.5, 'Rejouer', 'black');
}

//*********************

function JouerCoup(jeu, colonne) //Joue le coup choisi en fonction du joueur
{
  var tourJ1; // bool�en
  tourJ1 = QuiLeTour(jeu);
  if (tourJ1) {
    jeu[colonne] += 'O';
  } else {
    jeu[colonne] += 'X';
  }
}

//************************

function AnnulerCoup(jeu, colonne) { // annule le dernier coup jou� dans la colonne re�u
  jeu[colonne] = SousChaine(jeu[colonne], 0, Longueur(jeu[colonne]) - 1);
}

//***************************

function nbCoups(jeu) { // renvoie le nombre de coup depuis le d�but de la partie
  var i, j; // compteurs
  var coups = 0; // nombre de coups

  for (i = 0; i < 7; i++) {
    for (j = 0; j < Longueur(jeu[i]); j++) {
      coups++;
    }
  }
  return coups;
}

//*******************************

function AnimPion(n, choixColonne, tailleColonne, couleur) { // permet le grossissement des pions dans les cases s�l�ctionn�es

  if (n >= TAILLE_CASE / 1.2) { // si le cercle est assez gros...
    CerclePlein(100 + choixColonne * TAILLE_CASE + TAILLE_CASE / 2, 100 + (6 - tailleColonne) * TAILLE_CASE + TAILLE_CASE / 2, TAILLE_CASE / 1.2, couleur); //... alors afficher le cercle avec sa taille finale
  } 
  else 
  {
    CerclePlein(100 + choixColonne * TAILLE_CASE + TAILLE_CASE / 2, 100 + (6 - tailleColonne) * TAILLE_CASE + TAILLE_CASE / 2, n, couleur); // ... sinon afficher a chaque fois le cercle en augmentant son rayon
    setTimeout(function() {AnimPion(n + 1, choixColonne, tailleColonne, couleur);}, 5);

  }
}

//**********************

function QuiLeTour() //Fonction determinant le tour actuel : renvoit un bool�en
{
  var coupJ1, coupJ2; //nombre de couops pour chacun des joueurs
  coupJ1 = 0;
  coupJ2 = 0;


  for (i = 0; i < 7; i++) {
    for (j = 0; j < Longueur(jeu[i]); j++) {
      if (CaractereEn(jeu[i], j) == 'O') {
        coupJ1++;
      } else if (CaractereEn(jeu[i], j) == 'X') {
        coupJ2++;
      }
    }
  }

  if (coupJ1 == coupJ2) return true; //tourJ1 devient vrai
  else
  return false; //tourJ1 devient faux
}

//*****************

function Cercle2(x, y, rayon, epaisseur, couleur1, couleur2) { // un anneau d'�paisseur 'epaisseur' (=param�tre) ; coleur1: couleur de l'anneau; couleur2: couleur de l'interieure de l'anneau
  CerclePlein(x, y, rayon, couleur1); //cercle
  CerclePlein(x, y, rayon - epaisseur, couleur2); //Interieur du cercle
}

//*************IA****************
//L'IA jouera : X

function CalcIA(jeu, profondeur) //fonction decidant du choix de l'IA : renvoit un entier
{
  var i;
  var choixColonne; //colonne choisit par l'IA
  var valeur;  // note attribu�e � chacun des coups
  var valeurMax = -1000000; // la meilleure note

  //choixColonne = 0;

  for (i = 0; i < 7; i++) //on parcourt les colonnes
  {
    if (Longueur(jeu[i]) < 6) {
      JouerCoup(jeu, i); //simulation du coup
      valeur = Min(jeu, profondeur - 1); //le coup jou� re�oit une note
      AnnulerCoup(jeu, i); //le coup simul� est annul�
      if (valeur > valeurMax || (valeur == valeurMax && Hasard(2) == 0)) //Garder en memoire la colonne ayant re�u la meilleur note ET choix al�atoire si plusieurs colonnes ont la m�me notes
      {
        choixColonne = i;
        valeurMax = valeur;
      }
    }

  }

  return choixColonne; //On retourne la colonne qui a re�u la meilleur note
}



function Min(jeu, profondeur) //fonction renvoyant la valeur d'�valuation minimum des fils
{
  var valeurMin = 10000; // la plus mauvaise note obtenue
  var valeur; // note attribu�e � chacun des coups
  var i;

  if (profondeur == 0 || Termine(jeu, true) != '') valeurMin = Evaluation(jeu);
  else {
    for (i = 0; i < 7; i++) {
      if (Longueur(jeu[i]) < 6) {
        JouerCoup(jeu, i);
        valeur = Max(jeu, profondeur - 1);
        AnnulerCoup(jeu, i);

        if (valeur < valeurMin) valeurMin = valeur;
      }


    }
  }

  return valeurMin;
}



function Max(jeu, profondeur) //fonction renvoyant la valeur d'�valuation maximum des fils
{
  var valeurMax = -10000; // la meilleure note obtenue
  var valeur; // note attribu�e � chacun des coups
  var i;

  if (profondeur == 0 || Termine(jeu, true) != '') valeurMax = Evaluation(jeu);
  else {
    for (i = 0; i < 7; i++) {
      if (Longueur(jeu[i]) < 6) {
        JouerCoup(jeu, i);
        valeur = Min(jeu, profondeur - 1);
        AnnulerCoup(jeu, i);

        if (valeur > valeurMax) valeurMax = valeur;
      }

    }
  }
  return valeurMax;
}



function Evaluation(jeu) //Evalue le tableau de jeu a un moment donn� : retourne une note
{
  var nbCoups = 0; // nombre de coup jou�

  for (i = 0; i < 7; i++) {
    for (j = 0; j < Longueur(jeu[i]); j++) {
      if (CaractereEn(jeu[i], j) != '') {
        nbCoups++;
      }
    }
  }

  if (Termine(jeu, true) == 'O') {
    return -1000 + nbCoups; // On favorise le fait de perdre lentement
  } else if (Termine(jeu, true) == 'X') {
    return 1000 - nbCoups; // On favorise le fait de gagner rapidement
  } else
  return 0;

}
