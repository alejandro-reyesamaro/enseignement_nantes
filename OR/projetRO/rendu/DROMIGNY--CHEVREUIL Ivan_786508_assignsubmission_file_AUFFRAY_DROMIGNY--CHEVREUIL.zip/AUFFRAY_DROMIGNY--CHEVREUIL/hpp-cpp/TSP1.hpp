/* Fichier contenant le header du Voyageur de commerce en Brute Force par : Auffray Baptiste et Dromigny--Chevreuil Ivan */

                                                                             
#ifndef TSP1_H                                                                  
#define TSP1_H                                                                  
               
#include "structure.hpp"


unsigned int factorial(unsigned int n);

void TSP1(donnees &p);

#endif //TSP1_H