README du projet de RO
Chedotal Corentin & Duclos Romain 601A

Note, le fichier bladeflyerii.cpp ne marche pas.
Comme nous n'avons pas terminé le calcul des distances nous n'avons pas pu testé la résolution complète du projet.

Le fichier test.cpp permet de tester toutes nos méthodes et structures de données sur l'instance exemple.dat
