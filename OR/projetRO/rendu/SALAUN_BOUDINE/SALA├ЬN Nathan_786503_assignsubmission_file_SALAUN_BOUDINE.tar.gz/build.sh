g++ -O2 -o projet -g projet_SALAUN_BOUDINE.cpp -lm -lglpk
