./build.sh && ./projet A/VRPA10.dat
