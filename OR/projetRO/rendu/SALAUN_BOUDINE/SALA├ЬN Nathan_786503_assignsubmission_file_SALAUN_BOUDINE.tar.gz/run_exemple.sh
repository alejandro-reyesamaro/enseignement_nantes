./build.sh && ./projet exemple.dat
