/* 
   GAILLARD Florent
   MONNEAU Dylan 
   601A
*/

#include <stdio.h>
#include <stdlib.h>
#include <vector>

#include "donnees.hpp"

int ajoutPossible(std::vector<int>, int, std::vector<int>, int);

std::vector<std::vector<int> > regroupementPossible(donnees);